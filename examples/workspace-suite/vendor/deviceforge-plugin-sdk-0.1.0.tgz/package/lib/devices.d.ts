import type { Dispose, HostResult, Job, JsonValue } from './models.js';
export interface DeviceCapability {
    readonly id: string;
    readonly version: number;
    readonly operation: string;
    readonly scope: 'provider' | 'device';
    readonly access: 'read' | 'write';
    readonly executionTimeoutMs?: number;
}
export interface DeviceProviderDefinition {
    readonly apiVersion: number;
    readonly platform: string;
    readonly discoverOperation: string;
    readonly capabilities: readonly DeviceCapability[];
}
export interface DeviceProviderInfo {
    readonly id: string;
    readonly generation: string;
    readonly version: string;
    readonly definition: DeviceProviderDefinition;
}
export interface DeviceRef {
    readonly providerId: string;
    readonly generation: string;
    readonly localId: string;
}
export interface CapabilityAvailability {
    readonly id: string;
    readonly version: number;
    readonly available: boolean;
    readonly reason: string | null;
}
export interface ProvidedDevice {
    readonly reference: DeviceRef;
    readonly state: 'online' | 'offline' | 'unauthorized' | 'unknown';
    readonly rawState?: string;
    readonly model: string | null;
    readonly capabilities: readonly CapabilityAvailability[];
}
export interface DeviceDirectory {
    readonly provider: DeviceProviderInfo;
    readonly observedAt: number;
    readonly discoveryJobId: string;
    readonly devices: readonly ProvidedDevice[];
}
export interface DeviceAction {
    readonly providerId: string;
    readonly generation: string;
    readonly deviceId: string | null;
    readonly capability: string;
    readonly version: number;
    readonly input: {
        readonly [key: string]: JsonValue;
    };
}
export interface DeviceSnapshot {
    readonly providers: readonly DeviceProviderInfo[];
    readonly directories: readonly DeviceDirectory[];
    readonly selection: DeviceRef | null;
    readonly selected: ProvidedDevice | null;
}
export interface DeviceAccess {
    readonly refreshProviders: (signal: AbortSignal) => Promise<HostResult<readonly DeviceProviderInfo[]>>;
    readonly refreshDirectories: (signal: AbortSignal) => Promise<HostResult<readonly DeviceDirectory[]>>;
    readonly refreshProvider: (id: string, generation: string, signal: AbortSignal) => Promise<HostResult<DeviceDirectory>>;
    readonly select: (reference: DeviceRef | null) => void;
    readonly snapshot: () => DeviceSnapshot;
    readonly subscribe: (listener: (snapshot: DeviceSnapshot) => void) => Dispose;
    readonly invoke: (action: DeviceAction, signal: AbortSignal) => Promise<HostResult<Job>>;
}
